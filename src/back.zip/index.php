<?php
require_once "Router.php";

// CONTROLLERS
require_once "controllers/AuthController.php";
require_once "controllers/TaskController.php";
require_once "controllers/ProjectController.php";

// HELPERS
require_once "helpers/Response.php";
require_once "helpers/SecurityMiddleware.php";

// =================== CORS PRIMERO ===================
// Establecer headers CORS inmediatamente, antes de cualquier validación
SecurityMiddleware::setCORSHeaders();

// Manejar peticiones OPTIONS inmediatamente
if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit(0);
}

// Inicializar router
$router = new Router();

// =================== RUTAS PÚBLICAS ===================
// Login no requiere autenticación, pero sí validación de origin
$router->add("POST", "/login", function () {
    SecurityMiddleware::publicRoute();
    $authController = new AuthController();
    $authController->login();
});

// =================== RUTAS PROTEGIDAS ===================
// Todas estas rutas requieren autenticación JWT y validación de origin

$router->add("POST", "/change-password", function () {
    SecurityMiddleware::requireAuth();
    $authController = new AuthController();
    $authController->changePassword();
});

$router->add("GET", "/projects", function () {
    SecurityMiddleware::requireAuth();
    $projectController = new ProjectController();
    $projectController->getAll();
});

$router->add("POST", "/projects", function () {
    SecurityMiddleware::requireAuth();
    $projectController = new ProjectController();
    $projectController->create();
});

$router->add("GET", "/projects/{slug}", function ($slug) {
    SecurityMiddleware::requireAuth();
    $projectController = new ProjectController();
    $projectController->getBySlug($slug);
});

$router->add("GET", "/projects/{projectId}/tasks", function ($projectId) {
    SecurityMiddleware::requireAuth();
    $taskController = new TaskController();
    $taskController->getByProjectId($projectId);
});

$router->add("POST", "/tasks/{projectId}", function ($projectId) {
    SecurityMiddleware::requireAuth();
    $taskController = new TaskController();
    $taskController->create($projectId);
});

$router->add("PATCH", "/tasks/{taskId}/status", function ($taskId) {
    SecurityMiddleware::requireAuth();
    $taskController = new TaskController();
    $taskController->updateStatus($taskId);
});

$router->add("PATCH", "/tasks/{taskId}/worked-hours", function ($taskId) {
    SecurityMiddleware::requireAuth();
    $taskController = new TaskController();
    $taskController->updateWorkedHours($taskId);
});

$router->add("PUT", "/tasks/{taskId}", function ($taskId) {
    SecurityMiddleware::requireAuth();
    $taskController = new TaskController();
    $taskController->update($taskId);
});

$router->add("DELETE", "/tasks/{taskId}", function ($taskId) {
    SecurityMiddleware::requireAuth();
    $taskController = new TaskController();
    $taskController->delete($taskId);
});

// Manejar errores globales
try {
    $router->dispatch();
} catch (Exception $e) {
    Response::error("Error interno del servidor: " . $e->getMessage(), 500);
}
?>
